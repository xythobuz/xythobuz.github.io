/*
 * File:		syscalls.h
 * Creator:		Thomas Buck <taucher.bodensee@gmail.com>
 * License:		Beer-Ware
 * Date:		19.12.2010
 * Description:	This Header defines some of the built-in syscalls as functions you can call in C!
 */

int Serial_WriteByte( unsigned char val );				// Transmit (buffered) a byte via the Serial Port
int Serial_Open( unsigned char *conf );					// Open the serial port
int Serial_Close( int mode );							// Close the serial port
int Serial_ReadByte( unsigned char *dest );				// Read a byte from the serial ports fifo
int Serial_GetRxBufferSize( void );					// Get amount of data in rx buffer
//int App_RUNMAT( int runMode, unsigned short stripNum );	// Open Run-Mat
int Serial_ClearTransmitBuffer(void);
int Serial_ClearRecieveBuffer(void);