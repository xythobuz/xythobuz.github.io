/*****************************************************************/
/*                                                               */
/*   CASIO fx-9860G SDK Library                                  */
/*                                                               */
/*   File name : [ProjectName].c                                 */
/*                                                               */
/*   Copyright (c) 2006 CASIO COMPUTER CO., LTD.                 */
/*                                                               */
/*****************************************************************/
#include "fxlib.h"


//****************************************************************************
//  AddIn_main (Sample program main function)
//
//  param   :   isAppli   : 1 = This application is launched by MAIN MENU.
//                        : 0 = This application is launched by a strip in eACT application.
//
//              OptionNum : Strip number (0~3)
//                         (This parameter is only used when isAppli parameter is 0.)
//
//  retval  :   1 = No error / 0 = Error
//
//****************************************************************************
int AddIn_main(int isAppli, unsigned short OptionNum)
{
    unsigned int key;
    unsigned char conf[6];
    int tmp;
    unsigned char c;

    Bdisp_AllClr_VRAM();

    locate(5,1);
    Print("rRemote");
    locate(1,6);
    Print("CTRLS: Arrows!");
    locate(1,7);
    Print("Stop: F6");
    locate(1,2);
 
    conf[0] = 0; // always 0
    conf[1] = 5; // 0=300, 1=600, 2=1200, 3=2400, 4=4800, 5=9600, 6=19200, 7=38400, 8=57600, 9=115200 baud
    conf[2] = 0; // parity: 0=no; 1=odd; 2=even
    conf[3] = 0; // datalength: 0=8 bit; 1=7 bit
    conf[4] = 0; // stop bits: 0=one; 1=two
    conf[5] = 0; // always 0

    tmp = Serial_Open( conf );
    c = '0';
    c += (unsigned char)tmp;
    PrintC( &c );

    if (tmp == 3) {
	Serial_Close(1);
	tmp = Serial_Open( conf );
	c = '0' + (unsigned char)tmp;
	Print(", close, ");
	PrintC( &c );
    }

    Bdisp_PutDisp_DD();

    tmp = 0;
	
	
	
    while( IsKeyDown( KEY_CTRL_EXIT ) == 0 ) {
	if (Serial_GetRxBufferSize() > 0 ) {
	    if (tmp == 21)
		tmp = 0;
	    tmp++;
	    locate(tmp,8);
	    Serial_ReadByte( &c );
	    PrintC( &c );
	}
	Bdisp_PutDisp_DD();
	locate(1,3);
	if (IsKeyDown(  KEY_CTRL_UP )) {
	    while(IsKeyDown(KEY_CTRL_UP));
	    Serial_WriteByte('w');
	    Print((unsigned char*)"FW   ");
	    continue;
	}
	if (IsKeyDown(  KEY_CTRL_DOWN )) {
		while(IsKeyDown(KEY_CTRL_DOWN));
	    Serial_WriteByte('s');
	    Print((unsigned char*)"BW   ");
	    continue;
	}
	if (IsKeyDown(  KEY_CTRL_LEFT )) {
		while(IsKeyDown(KEY_CTRL_LEFT));
	    Serial_WriteByte('a');
	    Print((unsigned char*)"LEFT ");
	    continue;
	}
	if (IsKeyDown(  KEY_CTRL_RIGHT )) {
		while(IsKeyDown(KEY_CTRL_RIGHT));
	    Serial_WriteByte('d');
	    Print((unsigned char*)"RIGHT");
	    continue;
	}
	if (IsKeyDown(  KEY_CTRL_F6 )) {
		while(IsKeyDown(KEY_CTRL_F6));
	    Serial_WriteByte(' ');
	    Print((unsigned char*)"STOP ");
	    continue;
	}
    }

    locate(1,4);
    Print((unsigned char*)"Closing and exiting!");
    tmp = Serial_Close(1);
    c = '0' + (unsigned char)tmp;
    locate(1,5);
    PrintC( &c );
    Bdisp_PutDisp_DD();
    Sleep(1000);

    return 1;
}




//****************************************************************************
//**************                                              ****************
//**************                 Notice!                      ****************
//**************                                              ****************
//**************  Please do not change the following source.  ****************
//**************                                              ****************
//****************************************************************************


#pragma section _BR_Size
unsigned long BR_Size;
#pragma section


#pragma section _TOP

//****************************************************************************
//  InitializeSystem
//
//  param   :   isAppli   : 1 = Application / 0 = eActivity
//              OptionNum : Option Number (only eActivity)
//
//  retval  :   1 = No error / 0 = Error
//
//****************************************************************************
int InitializeSystem(int isAppli, unsigned short OptionNum)
{
    return INIT_ADDIN_APPLICATION(isAppli, OptionNum);
}

#pragma section

