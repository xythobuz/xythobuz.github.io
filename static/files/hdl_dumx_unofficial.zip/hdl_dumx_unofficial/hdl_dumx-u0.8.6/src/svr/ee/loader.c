/*
 * svr/ee/loader.c
 * $Id: loader.c,v 1.11 2006/06/18 13:13:13 bobi Exp $
 *
 * Copyright 2004 Bobi B., w1zard0f07@yahoo.com
 *
 * This file is part of hdl_dump.
 *
 * hdl_dump is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * hdl_dump is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with hdl_dump; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include <tamtypes.h>
#include <kernel.h>
#include <sifrpc.h>
#include <loadfile.h>
#include <fileio.h>
#include <iopcontrol.h>
#include <libmc.h>
#include <ps2ip.h>
#include <iopheap.h>
#include <sbv_patches.h>

#include <fileXio_rpc.h>
#include <libhdd.h>

#include <errno.h>
#include <string.h>
#include <malloc.h>
#include <sys/fcntl.h>
#include <sys/stat.h>
#include <sys/ioctl.h>

#include "graph.h"
#include "libpad.h"


#define APP_NAME "hdld_svr"
#define VERSION "u0.8.6"


#if 1 /* debugging */
#  define printf scr_printf
#else
#  define printf(...)
#  define init_scr(...)
#endif


#define RESET_IOP
#define LOAD_MRBROWN_PATCHES
#define LOAD_SIOMAN_AND_MC


extern u8 *iomanx_irx;
extern int size_iomanx_irx;

extern u8 *ps2dev9_irx;
extern int size_ps2dev9_irx;

extern u8 *ps2ip_irx;
extern int size_ps2ip_irx;

extern u8 *ps2smap_irx;
extern int size_ps2smap_irx;

extern u8 *ps2atad_irx;
extern int size_ps2atad_irx;

//ELF loading from modified ulaunchelf's original Mr. Brown elf loader

#define MAX_PATH 1025

extern u8 *load_elf;
extern int size_load_elf;

// ELF-loading stuff
#define ELF_MAGIC		0x464c457f
#define ELF_PT_LOAD		1

//------------------------------
typedef struct
{
	u8	ident[16];			// struct definition for ELF object header
	u16	type;
	u16	machine;
	u32	version;
	u32	entry;
	u32	phoff;
	u32	shoff;
	u32	flags;
	u16	ehsize;
	u16	phentsize;
	u16	phnum;
	u16	shentsize;
	u16	shnum;
	u16	shstrndx;
} elf_header_t;
//------------------------------
typedef struct
{
	u32	type;				// struct definition for ELF program section header
	u32	offset;
	void	*vaddr;
	u32	paddr;
	u32	filesz;
	u32	memsz;
	u32	flags;
	u32	align;
} elf_pheader_t;
//--------------------------------------------------------------
//End of data declarations
//--------------------------------------------------------------
//Start of function code
//--------------------------------------------------------------
// RunLoaderElf loads LOADER.ELF from program memory and passes
// args of selected ELF and partition to it
// Modified version of loader from Independence
//	(C) 2003 Marcus R. Brown <mrbrown@0xd6.org>
//------------------------------
void RunLoaderElf(char *filename, char *party)
{
	u8 *boot_elf;
	elf_header_t *eh;
	elf_pheader_t *eph;
	void *pdata;
	int ret, i;
	char *argv[2];

/* NB: LOADER.ELF is embedded  */
	boot_elf = (u8 *)&load_elf;
	eh = (elf_header_t *)boot_elf;
	if (_lw((u32)&eh->ident) != ELF_MAGIC)
		while (1);

	eph = (elf_pheader_t *)(boot_elf + eh->phoff);

/* Scan through the ELF's program headers and copy them into RAM, then
									zero out any non-loaded regions.  */
	for (i = 0; i < eh->phnum; i++)
	{
		if (eph[i].type != ELF_PT_LOAD)
		continue;

		pdata = (void *)(boot_elf + eph[i].offset);
		memcpy(eph[i].vaddr, pdata, eph[i].filesz);

		if (eph[i].memsz > eph[i].filesz)
			memset(eph[i].vaddr + eph[i].filesz, 0,
					eph[i].memsz - eph[i].filesz);
	}

/* Let's go.  */
	fioExit();
	SifInitRpc(0);
	SifExitRpc();
	FlushCache(0);
	FlushCache(2);

	argv[0] = filename;
	argv[1] = party;
	ExecPS2((void *)eh->entry, 0, 2, argv);
}
//------------------------------
//End of func:  void RunLoaderElf(char *filename, char *party)
//--------------------------------------------------------------



//PAD functions from ps2sdk sample by oopo

/*
 * Global var's
 */
// pad_dma_buf is provided by the user, one buf for each pad
// contains the pad's current state
static char padBuf[256] __attribute__((aligned(64)));
static char actAlign[6];
static int actuators;

/*
 * waitPadReady()
 */
int waitPadReady(int port, int slot)
{
    int state;
    int lastState;
    char stateString[16];

    state = padGetState(port, slot);
    lastState = -1;
    while((state != PAD_STATE_STABLE) && (state != PAD_STATE_FINDCTP1)) {
        if (state != lastState) {
            padStateInt2String(state, stateString);
      //      printf("Please wait, pad(%d,%d) is in state %s\n", port, slot, stateString);
        }
        lastState = state;
        state=padGetState(port, slot);
    }
    // Were the pad ever 'out of sync'?
    if (lastState != -1) {
  //      printf("Pad OK!\n");
    }
    return 0;
}


/*
 * initializePad()
 */
int
initializePad(int port, int slot)
{

    int ret;
    int modes;
    int i;

    waitPadReady(port, slot);

    // How many different modes can this device operate in?
    // i.e. get # entrys in the modetable
    modes = padInfoMode(port, slot, PAD_MODETABLE, -1);
//    printf("The device has %d modes\n", modes);

    if (modes > 0) {
//        printf("( ");
        for (i = 0; i < modes; i++) {
 //           printf("%d ", padInfoMode(port, slot, PAD_MODETABLE, i));
        }
 //       printf(")");
    }

 //   printf("It is currently using mode %d\n", padInfoMode(port, slot, PAD_MODECURID, 0));

    // If modes == 0, this is not a Dual shock controller 
    // (it has no actuator engines)
    if (modes == 0) {
//        printf("This is a digital controller?\n");
        return 1;
    }

    // Verify that the controller has a DUAL SHOCK mode
    i = 0;
    do {
        if (padInfoMode(port, slot, PAD_MODETABLE, i) == PAD_TYPE_DUALSHOCK)
            break;
        i++;
    } while (i < modes);
    if (i >= modes) {
 //       printf("This is no Dual Shock controller\n");
        return 1;
    }

    // If ExId != 0x0 => This controller has actuator engines
    // This check should always pass if the Dual Shock test above passed
    ret = padInfoMode(port, slot, PAD_MODECUREXID, 0);
    if (ret == 0) {
 //       printf("This is no Dual Shock controller??\n");
        return 1;
    }

 //   printf("Enabling dual shock functions\n");

    // When using MMODE_LOCK, user cant change mode with Select button
    padSetMainMode(port, slot, PAD_MMODE_DUALSHOCK, PAD_MMODE_LOCK);

    waitPadReady(port, slot);
//    printf("infoPressMode: %d\n", padInfoPressMode(port, slot));

    waitPadReady(port, slot);        
//    printf("enterPressMode: %d\n", padEnterPressMode(port, slot));

    waitPadReady(port, slot);
    actuators = padInfoAct(port, slot, -1, 0);
//    printf("# of actuators: %d\n",actuators);

    if (actuators != 0) {
        actAlign[0] = 0;   // Enable small engine
        actAlign[1] = 1;   // Enable big engine
        actAlign[2] = 0xff;
        actAlign[3] = 0xff;
        actAlign[4] = 0xff;
        actAlign[5] = 0xff;

        waitPadReady(port, slot);
//        printf("padSetActAlign: %d\n", padSetActAlign(port, slot, actAlign));
    }
    else {
 //       printf("Did not find any actuators.\n");
    }

    waitPadReady(port, slot);

    return 1;
}

#define IPCONF_MAX_LEN (3 * 16)
char __attribute__((aligned(16))) if_conf [IPCONF_MAX_LEN];
size_t if_conf_len;

const char *default_ip = "192.168.0.10";
const char *default_mask = "255.255.255.0";
const char *default_gateway = "192.168.0.1";


/**************************************************************/
int /* "192.168.0.10 255.255.255.0 192.168.0.1" */
setup_ip (const char *ipconfig_dat_path,
	  char outp [IPCONF_MAX_LEN], size_t *length)
{
  int result = 0;
  int conf_ok = 0;
#if defined (LOAD_SIOMAN_AND_MC)
  int fd = fioOpen (ipconfig_dat_path, O_RDONLY);
  if (!(fd < 0))
    { /* configuration file found */
      char tmp [IPCONF_MAX_LEN];
      int len = fioRead (fd, tmp, IPCONF_MAX_LEN - 1);
      fioClose (fd);

      if (len > 0)
	{
	  int data_ok = 1;
	  int i;
	  tmp [len] = '\0';
	  for (i=0; data_ok && i<len; ++i)
	    if (isdigit (tmp [i]) || tmp [i] == '.')
	      ;
	    else if (isspace (tmp [i]))
	      tmp [i] = '\0';
	    else
	      data_ok = 0;

	  if (data_ok)
	    {
	      memcpy (outp, tmp, IPCONF_MAX_LEN);
	      conf_ok = 1;
	      *length = len;
	    }
	  else
	    /* bad format */
	    result = -2;
	}
    }
  else
    /* not found */
    result = -1;
#endif /* LOAD_SIOMAN_AND_MC? */

  if (!conf_ok)
    { /* configuration file not found; use hard-coded defaults */
      int len, pos = 0;

      len = strlen (default_ip);
      memcpy (outp + pos, default_ip, len); pos += len;
      *(outp + pos++) = '\0';

      len = strlen (default_mask);
      memcpy (outp + pos, default_mask, len); pos += len;
      *(outp + pos++) = '\0';

      len = strlen (default_gateway);
      memcpy (outp + pos, default_gateway, len); pos += len;
      *(outp + pos++) = '\0';
      *length = pos;
    }

  return (result);
}


/**************************************************************/
static int
load_modules ()
{
  const char *STEP_OK = "*";
  const char *FAILED = "failed to load with";
  int ret, ipcfg_ret = 0;

  size_t i;
  const char *IPCONFIG_DAT_PATHS[] =
    {
      "mc0:/BIDATA-SYSTEM/IPCONFIG.DAT", /* japan */
      "mc0:/BADATA-SYSTEM/IPCONFIG.DAT", /* us */
      "mc0:/BEDATA-SYSTEM/IPCONFIG.DAT", /* europe */
      "mc0:/SYS-CONF/IPCONFIG.DAT", /* old location */
      "mc1:/BIDATA-SYSTEM/IPCONFIG.DAT", /* japan */
      "mc1:/BADATA-SYSTEM/IPCONFIG.DAT", /* us */
      "mc1:/BEDATA-SYSTEM/IPCONFIG.DAT", /* europe */
      "mc1:/SYS-CONF/IPCONFIG.DAT", /* old location */
      NULL
    };

#if defined (LOAD_MRBROWN_PATCHES)
  sbv_patch_enable_lmb ();
  sbv_patch_disable_prefix_check ();
  scr_printf (STEP_OK);
#endif

#if defined (LOAD_SIOMAN_AND_MC)
  ret = SifLoadModule ("rom0:SIO2MAN", 0, NULL);
  if (ret > 0)
    scr_printf (STEP_OK);
  else
    {
      scr_printf ("\nrom0:SIO2MAN %s %d\n", FAILED, ret);
      return (-1);
    }

  ret = SifLoadModule ("rom0:PADMAN", 0, NULL);
  if (ret > 0)
    scr_printf (STEP_OK);
  else
    {
      scr_printf ("\nrom0:PADMAN %s %d\n", FAILED, ret);
      return (-1);
    }

  ret = SifLoadModule ("rom0:MCMAN", 0, NULL);
  if (ret > 0)
    scr_printf (STEP_OK);
  else
    {
      scr_printf ("\nrom0:MCMAN %s %d\n", FAILED, ret);
      return (-1);
    }

  ret = SifLoadModule ("rom0:MCSERV", 0, NULL);
  if (ret > 0)
    scr_printf (STEP_OK);
  else
    {
      scr_printf ("\nrom0:MCSERV %s %d\n", FAILED, ret);
      return (-1);
    }
#endif

  SifExecModuleBuffer (&iomanx_irx, size_iomanx_irx, 0, NULL, &ret);
  if (ret == 0)
    scr_printf (STEP_OK);
  else
    {
      scr_printf ("IOMANX.IRX %s %d\n", FAILED, ret);
      return (-1);
    }

  SifExecModuleBuffer (&ps2dev9_irx, size_ps2dev9_irx, 0, NULL, &ret);
  if (ret == 0)
    scr_printf (STEP_OK);
  else
    {
      scr_printf ("PS2DEV9.IRX %s %d\n", FAILED, ret);
      return (-1);
    }

  SifExecModuleBuffer (&ps2atad_irx, size_ps2atad_irx, 0, NULL, &ret);
  if (ret == 0)
    scr_printf (STEP_OK);
  else
    {
      scr_printf ("PS2ATAD.IRX %s %d\n", FAILED, ret);
      return (-1);
    }

  SifExecModuleBuffer (&ps2ip_irx, size_ps2ip_irx, 0, NULL, &ret);
  if (ret == 0)
    scr_printf (STEP_OK);
  else
    {
      scr_printf ("PS2IP.IRX %s %d\n", FAILED, ret);
      return (-1);
    }

  ipcfg_ret = -1;
  for (i = 0; ipcfg_ret != 0 && IPCONFIG_DAT_PATHS[i] != NULL; ++i)
    {
      ipcfg_ret = setup_ip (IPCONFIG_DAT_PATHS[i], if_conf, &if_conf_len);
    }

  SifExecModuleBuffer (&ps2smap_irx, size_ps2smap_irx,
		       if_conf_len, if_conf, &ret);
  if (ret == 0)
    scr_printf (STEP_OK);
  else
    {
      scr_printf ("PS2SMAP.IRX %s %d\n", FAILED, ret);
      return (-1);
    }

  scr_printf ("\n");

  switch (ipcfg_ret)
    {
    case 0:
      scr_printf ("\nusing %s\n", IPCONFIG_DAT_PATHS[i - 1]);
      break;

    case -1:
      scr_printf ("\nuse one of the following locations to set IP address:\n");
      for (i = 0; IPCONFIG_DAT_PATHS[i] != NULL; ++i)
	scr_printf ("   %s\n", IPCONFIG_DAT_PATHS[i]);
      break;

    case -2:
      scr_printf ("\nusing %s\n", IPCONFIG_DAT_PATHS[i - 1]);
      scr_printf ("\ninvalid configuration file format; use:\n"
		  "ip_address network_mask gateway_ip\n"
		  "separated by a single space; for example:"
		  "192.168.0.10 255.255.255.0 192.168.0.1\n\n");
      break;
    }
  scr_printf ("Playstation 2 IP address: %s\n", if_conf);

  return (0);
}


/**************************************************************/
//--------------------------------------------------------------
//exists.  Tests if a file exists or not
//From uLaunchELF
//------------------------------
int exists(char *path)
{
	int fd;

	fd = fioOpen(path, O_RDONLY);
	if( fd < 0 )
		return 0;
	fioClose(fd);
	return 1;
}
//--------------------------------------------------------------
//endfunc: exists
//------------------------------
int
main (int argc,
      char *argv [])
{
//pad variables
    int ret;
    int port, slot;
    int i;
    struct padButtonStatus buttons;
    u32 paddata;
    u32 old_pad = 0;
    u32 new_pad;
//Elf loading variables
	char party[40];
	party[0] = 0;
	char path[MAX_PATH];

  SifInitRpc (0);

  init_scr ();
  scr_printf (APP_NAME "-" VERSION "\n");

  /* decide whether to load TCP/IP or it is already loaded */
  SifExitIopHeap ();
  SifLoadFileExit ();
  SifExitRpc ();

  SifIopReset (NULL /* "rom0:UDNL rom0:EELOADCNF" */, 0);
  while (SifIopSync ())
    ;
  SifInitRpc (0);

  if (load_modules () == 0)
    {
      scr_printf ("Ready\n");
    }
  else
    scr_printf ("Failed to load\n");

//PAD Section
	
    padInit(0);
    port = 0; // 0 -> Connector 1, 1 -> Connector 2
    slot = 0; // Always zero if not using multitap
	
    if((ret = padPortOpen(port, slot, padBuf)) == 0) {
        printf("padOpenPort failed: %d\n", ret);
        SleepThread();
    }
    
    if(!initializePad(port, slot)) {
        printf("pad initalization failed!\n");
        SleepThread();
    }

    for (;;) {      // We are phorever people
            
        i=0;
        ret=padGetState(port, slot);
        while((ret != PAD_STATE_STABLE) && (ret != PAD_STATE_FINDCTP1)) {
            if(ret==PAD_STATE_DISCONN) {
                printf("Pad(%d, %d) is disconnected\n", port, slot);
            }
            ret=padGetState(port, slot);
        }
        if(i==1) {
            printf("Pad: OK!\n");
        }
            
        ret = padRead(port, slot, &buttons); // port, slot, buttons
            
        if (ret != 0) {
            paddata = 0xffff ^ buttons.btns;
                
            new_pad = paddata & ~old_pad;
            old_pad = paddata;
                
            // Directions

            if((new_pad & PAD_CROSS) && (new_pad & PAD_TRIANGLE)) {
				__asm__ __volatile__("	li $3, 0x04;""	syscall;""	nop;");
            }
            if((new_pad & PAD_CIRCLE) && (new_pad & PAD_SQUARE)) {
				padPortClose(1,0);
				padPortClose(0,0);
			strcpy(path, "mc0:/BOOT/BOOT.ELF");
				if (!exists(path)){
					path[2] = '1';
					if (exists(path))
						goto finish;
				}else if (exists(path))
					goto finish;
			strcpy(path, "mc0:/BEDATA-SYSTEM/BOOT.ELF");
				if (!exists(path)){
					path[2] = '1';
					if (exists(path))
						goto finish;					
				}else if (exists(path))
					goto finish;
			strcpy(path, "mc0:/BADATA-SYSTEM/BOOT.ELF");
				if (!exists(path)){
					path[2] = '1';
					if (exists(path))
						goto finish;					
				}else if (exists(path))
					goto finish;
			strcpy(path, "mc0:/BIDATA-SYSTEM/BOOT.ELF");
				if (!exists(path)){
					path[2] = '1';
					if (exists(path))
						goto finish;					
				}else if (exists(path))
					goto finish;
finish:
			RunLoaderElf(path, party);
            }
        } 
    } // for

    printf("Goto sleep!\n");

  /* our job is done; IOP would handle the rest */
  SleepThread ();

  return (0);
}
