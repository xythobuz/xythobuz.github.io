#if !defined (_GRAPH_H)
#define _GRAPH_H

void init_scr();
void scr_printf(const char *format, ...);

#endif
