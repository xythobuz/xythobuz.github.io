/*
 * By: Thomas Buck <taucher.bodensee@gmail.com>
 * Visit: www.xythobuz.org
 */

#include <avr/io.h>
#include <util/delay.h>
#include <avr/interrupt.h>

#define DATA1 PB0
#define CLK1 PB1
#define LOAD1 PB2
#define P1 PORTB
#define D1 DDRB
#define DATA2 PD5
#define CLK2 PD4
#define LOAD2 PD3
#define P2 PORTD
#define D2 DDRD

#define DELAY 50
#define DELAY2 50

uint8_t display[10];
uint8_t display2[10];
uint8_t global_y = 0;

uint8_t ZFlogo[10] = { 0, 114, 90, 78, 0, 0, 126, 18, 2, 0 };


void initBuffer(uint8_t a) {
	int i;
	for (i = 0; i < 10; i++) {
		display[i] = a;
		display2[i] = a;
	}
}

void init(void) {
	D1 |= (1 << DATA1) | (1 << CLK1) | (1 << LOAD1); // PB 0 - 2 Ausgang
	D2 |= (1 << DATA2) | (1 << CLK2) | (1 << LOAD2);
	TCCR0B |= (1 << CS01) | (1 << CS00); // Prescaler: 64
	TIMSK |= (1 << TOIE0); // Enable Interrupt

	sei(); // Enable global interrupts
}

void setPixel(uint8_t x, uint8_t y) {
	display[x] |= (1 << y);
}

void setPixel2(uint8_t x, uint8_t y) {
	display2[x] |= (1 << y);
}

void delPixel(uint8_t x, uint8_t y) {
	display[x] &= ~(1 << y);
}

void delPixel2(uint8_t x, uint8_t y) {
	display2[x] &= ~(1 << y);
}

uint8_t getPixel(uint8_t x, uint8_t y) {
	if ((display[x] & (1 << y)) != 0) {
		return 1;
	} else {
		return 0;
	}
}

uint8_t getPixel2(uint8_t x, uint8_t y) {
	if ((display2[x] & (1 << y)) != 0) {
		return 1;
	} else {
		return 0;
	}
}

void shiftOut1(uint8_t a) {
	if (a == 0) {
		P1 &= ~(1 << DATA1);
	} else {
		P1 |= (1 << DATA1);
	}
	P1 |= (1 << CLK1);
	P1 &= ~(1 << CLK1);
}

void load1(void) {
	P1 |= (1 << LOAD1);
	P1 &= ~(1 << LOAD1);
}

void shiftOut2(uint8_t a) {
	if (a == 0) {
		P2 &= ~(1 << DATA2);
	} else {
		P2 |= (1 << DATA2);
	}
	P2 |= (1 << CLK2);
	P2 &= ~(1 << CLK2);
}

void load2(void) {
	P2 |= (1 << LOAD2);
	P2 &= ~(1 << LOAD2);
}

ISR(TIMER0_OVF_vect) {
	int8_t x;

	for (x = 0; x < 5; x++) {
		shiftOut1(0);
		shiftOut2(0);
	}
	shiftOut1(1);
	shiftOut2(1);
	x = global_y;
	while (x > 0) {
		x--;
		shiftOut1(0);
		shiftOut2(0);
	}

	for (x = 7; x >= 0; x--) {
		if (getPixel(global_y, x) == 1) {
			shiftOut1(1);
		} else {
			shiftOut1(0);
		}
		if (getPixel(global_y + 5, x) == 1) {
			shiftOut2(1);
		} else {
			shiftOut2(0);
		}
	}

	load1();
	load2();

	if (global_y < 4) {
		global_y++;
	} else {
		global_y = 0;
	}
}

void effect1(uint8_t num) {
	int i;
	while(num > 0) {
		for (i = 0; i < 10; i++) {
			if (display[i] < 255) {
				display[i]++;
			} else {
				display[i] = 0;
			}
		}
		_delay_ms(DELAY2);
		num--;
	}
	for (int i = 0; i < 10; i++) {
		display[i] = 0;
	}
}

void shiftDisplayY(uint8_t dir, uint8_t target) {
	uint8_t i, tmp;
	for (i = 0; i < 10; i++) {
		if (target == 2) {
			tmp = display2[i];
		} else {
			tmp = display[i];
		}
		if (dir == 0) {
			if (target != 2) {
				display[i] = display[i] >> 1;
			} else {
				display2[i] = display2[i] >> 1;
			}
			if ((tmp & 1) != 0) {
				if (target != 2) {
					display[i] |= 128;
				} else {
					display2[i] |= 128;
				}
			}
		} else {
			if (target != 2) {
				display[i] = display[i] << 1;
			} else {
				display2[i] = display2[i] << 1;
			}
			if ((tmp & 128) != 0) {
				if (target == 2) {
					display2[i] |= 1;
				} else {
					display[i] |= 1;
				}
			}
		}
	}
}

void shiftDisplayX(uint8_t dir, uint8_t target) {
	uint8_t i, tmp;
	if (dir == 0) {
		if (target != 2) {
			tmp = display[0];
		} else {
			tmp = display2[0];
		}
		for (i = 0; i < 9; i++) {
			if (target != 2) {
				display[i] = display[i+1];
			} else {
				display2[i] = display2[i+1];
			}
		}
		if (target != 2) {
			display[9] = tmp;
		} else {
			display2[9] = tmp;
		}	
	} else {
		if (target != 2) {
			tmp = display[9];
	} else {	
			tmp = display2[9];
		}
		for (i = 9; i > 0; i--) {
			if (target != 2) {
				display[i] = display[i-1];
			} else {
				display2[i] = display2[i-1];
			}
		}
		if (target != 2) {
			display[0] = tmp;
		} else {
			display2[0] = tmp;
		}
	}
}

void scrollAwayBottom(void) {
	int i, j;
	for (i = 0; i < 8; i++) {
		shiftDisplayY(1, 0);
		for (j = 0; j < 10; j++) {
			delPixel(j, 0);
		}
		_delay_ms(DELAY);
	}
}

void scrollAwayRight(void) {
	int i, j;
	for (i = 0; i < 10; i++) {
		shiftDisplayX(1, 0);
		for (j = 0; j < 8; j++) {
			delPixel(0, j);
		}
		_delay_ms(DELAY);
	}
}

void shoot(void) {
	int i, j;
	for (j = 0; j < 8; j++) {
		for (i = 0; i < 10; i++) {
			if (getPixel(i, j) == 0) {
				if (getPixel2(i, j) == 1) {
					setPixel(i, j);
					_delay_ms(DELAY2);
				}
			} else {
				if (getPixel2(i, j) == 0) {
					delPixel(i, j);
					_delay_ms(DELAY2);
				}
			}
		}
	}
}

void kill(uint8_t w) {
	int i, j;
	for (j = 0; j < 8; j++) {
		for (i = 0; i < 10; i++) {
			if (w == 0) {
				if (getPixel(i, j) == 1) {
					delPixel(i, j);
					_delay_ms(DELAY2);
				}
			} else {
				if (getPixel(i, j) == 0) {
					setPixel(i, j);
					_delay_ms(DELAY2);
				}
			}
		}
	}
}

void copyShape(uint8_t *array, uint8_t target) {
	int i;
	for (i = 0; i < 10; i++) {
		if (target == 2) {
			display2[i] = array[i];
		} else {
			display[i] = array[i];
		}
	}
}

void scrollInShapeTop(uint8_t *array) {
	int i, j, k = 8;
	initBuffer(0);
	copyShape(array, 2);
	for (j = 0; j < 8; j++) {
		k--;
		shiftDisplayY(1, 0);
		for (i = 0; i < 10; i++) {
			if (getPixel2(i, k) == 1) {
				setPixel(i, 0);
			}
		}
		_delay_ms(DELAY);
	}
}

void scrollInShapeLeft(uint8_t *array) {
	int i, j, k = 10;
	initBuffer(0);
	copyShape(array, 2);
	for (i = 0; i < 10; i++) {
		k--;
		shiftDisplayX(1, 0);
		for (j = 0; j < 8; j++) {
			if (getPixel2(k, j) == 1) {
				setPixel(0, j);
			}
		}
		_delay_ms(DELAY);
	}
}

int main(void) {
	uint8_t i;

	initBuffer(0);
	init();

	while(1) {
		initBuffer(255);
		_delay_ms(DELAY*50);
		effect1(255);

		scrollInShapeLeft(ZFlogo);
		for (i = 0; i < 10; i++) {
			shiftDisplayX(1, 0);
			_delay_ms(DELAY);
		}
		scrollAwayRight();
		_delay_ms(DELAY);

		scrollInShapeTop(ZFlogo);
		for (i = 0; i < 8; i++) {
			shiftDisplayY(1, 0);
			_delay_ms(DELAY);
		}
		scrollAwayBottom();
		_delay_ms(DELAY*10);

		for (i = 0; i < 2; i++) {
			copyShape(ZFlogo, 2);
			shoot();
			// _delay_ms(DELAY*10);
			kill(0);
		}
	}
	return 0;
}
